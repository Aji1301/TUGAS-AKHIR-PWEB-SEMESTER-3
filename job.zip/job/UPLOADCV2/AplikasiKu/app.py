from flask import current_app
from flask import Flask
from flask_mysqldb import MySQL
import os

# Konfigurasi folder untuk menyimpan file CV dan format yang diperbolehkan
UPLOAD_FOLDER = 'static/uploads/cv'
ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx'}

# Inisialisasi aplikasi Flask
app = Flask(__name__)
app.config["MYSQL_HOST"] = "localhost"
app.config['MYSQL_PORT'] = 3306
app.config["MYSQL_USER"] = "root"
app.config["MYSQL_PASSWORD"] = ""
app.config["MYSQL_DB"] = "db_pekerjaan1"
app.config['UPLOAD_FOLDER'] = os.getenv('UPLOAD_FOLDER', 'uploads/')
app.config['UPLOAD_FOLDER'] = 'static/uploads/profile_pictures'

app.secret_key = 'secret'

# Inisialisasi MySQL
mysql = MySQL(app)

# Import modul dan fungsi dari file lain
from AplikasiKu.controllers.jobs import (
    login as log,
    register as reg,
    akun as ak,
    require_login,
    explore as exp,
    form_cari as fc,
    cari_kerja as ck,
    form_tambah as ft,
    form_pelamar as fp,
    daftar_pelamar as dafp,
    logout as lo,
    index as ix,
    informasi_pekerjaan as ip,
    kategori_pekerjaan,
    hapus_data_pelamar,
    upload_profile_picture_route,
    profile_picture
)

# Rute untuk halaman utama
@app.route('/', methods=['GET', 'POST'])
def index():
    return ix()

# Rute untuk registrasi
@app.route('/register', methods=['GET', 'POST'])
def register():
    return reg()

# Rute untuk login
@app.route('/login', methods=['GET', 'POST'])
def login():
    return log()

# Rute untuk logout
@app.route('/logout')
def logout():
    return lo()

# Rute untuk akun pengguna
@app.route('/akun')
def akun():
    return ak()

@app.route('/upload_profile_picture', methods=['POST'])
def upload_profile_picture():
    return upload_profile_picture_route()

@app.route('/delete_profile_picture', methods=['POST'])
def delete_profile_picture():
    return delete_profile_picture()

from flask import send_from_directory

@app.route('/profile_picture>', methods=['POST'])
def profile_picture(filename):
    """
    Melayani gambar profil dari direktori yang dikonfigurasi.
    """
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


# Middleware untuk memeriksa login sebelum request
@app.before_request
def before_request():
    return require_login()

# Rute untuk halaman explore pekerjaan
@app.route('/explore')
def explore():
    return exp()

# Rute untuk menghapus data pekerjaan
@app.route('/delete/<int:pekerjaan_id>')
def delete(pekerjaan_id):
    return hapus_data_pelamar(pekerjaan_id)

# Rute untuk formulir pencarian pekerjaan
@app.route('/form_cari')
def form_cari():
    return fc()

# Rute untuk pekerjaan berdasarkan kategori
@app.route('/job_by_kategori/<int:kategori_id>')
def job_by_kategori(kategori_id):
    return kategori_pekerjaan(kategori_id)

# Rute untuk pencarian kerja
@app.route('/cari_kerja', methods=['POST'])
def cari_kerja():
    return ck()

# Rute untuk menambahkan pekerjaan
@app.route('/form_tambah', methods=['GET', 'POST'])
def form_tambah():
    return ft()



# Rute untuk formulir pelamar pekerjaan
@app.route('/form_pelamar/<int:pekerjaan_id>', methods=['GET', 'POST'])
def form_pelamar(pekerjaan_id):
    return fp(pekerjaan_id)

@app.route('/upload', methods=['POST'])
def upload_file():
    # Access the upload folder from Flask's configuration
    upload_folder = current_app.config['UPLOAD_FOLDER']
    return f'Files will be uploaded to: {upload_folder}'

# Rute untuk informasi pekerjaan
@app.route('/informasi_pekerjaan/<int:id>', methods=['GET', 'POST'])
def informasi_pekerjaan(id):
    return ip(id)

# Rute untuk daftar pelamar
@app.route('/daftar_pelamar/<int:pekerjaan_id>')
def daftar_pelamar(pekerjaan_id):
    return dafp(pekerjaan_id)

# Jalankan aplikasi


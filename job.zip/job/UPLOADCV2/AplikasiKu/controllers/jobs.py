from flask import render_template, request, redirect, url_for, session, flash, current_app, send_from_directory, abort
from werkzeug.utils import secure_filename
import os
import traceback, app

from AplikasiKu.models.jobs import (
    get_user_by_email,
    verify_password,
    create_user,
    get_user_pekerjaan,
    get_job_sebagian,
    get_jobs,
    add_jobs,
    add_pelamar,
    get_jobs_by_id,
    daftar_pelamar_by_job,
    explore as ex,
    get_jobs_by_id_2,
    jobs_category,
    get_job_by_categories,
    delete_job_by_id,
    email_exists,
    get_user_profile_picture,
    update_user_profile_picture,
    delete_user_profile_picture,
    allowed_file1,
    allowed_file
)

# Fungsi untuk halaman utama
def index():
    pekerjaan_s = get_job_sebagian()
    kategori = jobs_category()
    return render_template('index.html', pekerjaan_s=pekerjaan_s, kategori=kategori)

# Fungsi untuk login
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = get_user_by_email(email)
        if user and verify_password(user[2], password):  # Password hash di kolom ke-3
            session['user_id'] = user[0]  # Simpan user_id ke session
            session['username'] = user[1]  # Simpan username ke session
            session['email'] = user[3]
            # flash('Login berhasil!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Login gagal. Periksa email dan password.', 'error')
    return render_template('login.html')

# Fungsi untuk registrasi
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        if email_exists(email):
            flash('Email sudah digunakan. Silakan gunakan email lain.', 'warning')
            return redirect(url_for('register'))
        # Tambahkan pengguna ke database
        create_user(username, email, password)

        flash('Registrasi berhasil! Silakan login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

# Fungsi untuk akun pengguna
def akun():
    if 'user_id' not in session:
        flash('Silakan login terlebih dahulu.', 'warning')
        return redirect(url_for('login'))

    user_id = session['user_id']
    pekerjaan = get_user_pekerjaan(user_id)  # Data pekerjaan pengguna
    profile_picture = get_user_profile_picture(user_id)  # Ambil jalur foto profil

    return render_template(
        'akun.html',
        username=session['username'],
        email=session['email'],
        pekerjaan=pekerjaan,
        profile_picture=profile_picture
    )


# Middleware untuk memeriksa login
def require_login():
    restricted_paths = ['/akun', '/logout']
    if request.path in restricted_paths and 'user_id' not in session:
        flash('Silakan login untuk mengakses halaman ini.', 'warning')
        return redirect(url_for('login'))
    return None

# Fungsi untuk eksplorasi pekerjaan
def explore():
    sort_by = request.args.get('sort_by', 'most_recent')
    if sort_by == 'asc':
        sort_label= "Gaji paling rendah"
    elif sort_by == 'dsc':
        sort_label= "Gaji paling tinggi"
    else:
        sort_label="paling terbaru ditambah"
    
    pekerjaan = ex(sort_by)
    return render_template('explore.html', pekerjaan=pekerjaan, sort_label=sort_label, sort_by=sort_by)

def explore_sebagian():
    pekerjaan_s=get_job_sebagian()
    kategori=jobs_category()
    return render_template('index.html', pekerjaan_s=pekerjaan_s,kategori=kategori)

# Fungsi untuk menghapus data pelamar
def hapus_data_pelamar(pekerjaan_id):
    hapus=delete_job_by_id(pekerjaan_id)
    return redirect(url_for('akun')),hapus

# Fungsi untuk pencarian kerja
def form_cari():
    return render_template('form_cari.html')

def cari_kerja():
    experience = request.form['experience']
    if not experience:
        # flash("Harap isi kolom pencarian terlebih dahulu!", "error")
        return redirect(url_for('index'))
    jobs = get_jobs(experience)
    return render_template('cari_kerja.html', jobs=jobs)

# Fungsi untuk menambah pekerjaan
def form_tambah():
    if request.method == 'POST':
        posisi = request.form['posisi']
        perusahaan = request.form['Perusahaan']
        lokasi = request.form['lokasi']
        gaji = request.form['gaji']
        deskripsi = request.form['description']
        requirement = request.form['requirement']
        kategori_id = int(request.form['kategori_id'])

        add_jobs(posisi, perusahaan, lokasi, gaji, deskripsi, requirement, kategori_id)
        flash('Pekerjaan berhasil ditambahkan!', 'success')
        return redirect(url_for('explore'))
    return render_template('form_tambah.html')

# Fungsi untuk melamar pekerjaan
def form_pelamar(pekerjaan_id):
    if 'user_id' not in session:
        flash('Silakan login terlebih dahulu.', 'warning')
        return redirect(url_for('login'))

    if request.method == 'POST':
        nama = request.form['nama']
        email = request.form['email']
        no_tlp = request.form['no_tlp']
        pendidikan = request.form['pendidikan']
        skill = request.form['skill']
        user_id = session['user_id']

        # Proses upload file
        file = request.files.get('cv')
        if not file or file.filename == '':
            flash('File CV tidak valid. Harap unggah file yang sesuai.', 'error')
            return redirect(request.url)

        if allowed_file(file.filename):
            filename = secure_filename(file.filename)
            upload_folder = current_app.config.get('UPLOAD_FOLDER', 'static/uploads/cv')
            os.makedirs(upload_folder, exist_ok=True)  # Membuat folder jika belum ada
            file_path = os.path.join(upload_folder, filename)
            file.save(file_path)
        else:
            flash('Format file tidak diperbolehkan. Gunakan PDF, DOC, atau DOCX.', 'error')
            return redirect(request.url)

        # Simpan data pelamar ke database
        add_pelamar(nama, email, no_tlp, pendidikan, skill, pekerjaan_id, user_id, filename)
        flash('Lamaran berhasil dikirim!', 'success')
        return redirect(url_for('explore'))

    pekerjaan = get_jobs_by_id(pekerjaan_id)
    return render_template('form_pelamar.html', pekerjaan_id=pekerjaan_id, pekerjaan=pekerjaan)

# Fungsi daftar pelamar
def daftar_pelamar(pekerjaan_id):
    pelamar = daftar_pelamar_by_job(pekerjaan_id)
    pekerjaan = get_jobs_by_id(pekerjaan_id)
    return render_template('daftar_pelamar.html', pelamar=pelamar, pekerjaan=pekerjaan)

# Fungsi informasi pekerjaan
def informasi_pekerjaan(id):
    informasi = get_jobs_by_id_2(id)
    return render_template('informasi_pekerjaan.html', informasi=informasi)

# Fungsi kategori pekerjaan
def kategori_pekerjaan(kategori_id):
    tb_pekerjaan = get_job_by_categories(kategori_id)
    return render_template('job_by_kategori.html', tb_pekerjaan=tb_pekerjaan)

def upload_profile_picture_route():
    if 'profile_picture' not in request.files:
        flash('Tidak ada file yang diunggah', 'error')
        return redirect(url_for('akun'))

    file = request.files['profile_picture']

    # Pastikan nama file tidak kosong
    if file.filename == '':
        flash('Tidak ada file yang dipilih.', 'error')
        return redirect(url_for('akun'))

    if allowed_file1(file.filename):
        filename = secure_filename(file.filename)
        upload_folder = current_app.config.get('UPLOAD_FOLDER', 'static/uploads/profile_pictures')
        os.makedirs(upload_folder, exist_ok=True)  # Membuat folder jika belum ada
        file_path = os.path.join(upload_folder, filename)
        file.save(file_path)

        # Simpan path ke database
        update_user_profile_picture(session['user_id'], file_path)
        flash('Foto profil berhasil diperbarui!', 'success')
    else:
        flash('Format file tidak diperbolehkan. Gunakan format JPG, PNG, atau GIF.', 'error')

    return redirect(url_for('akun'))

def profile_picture(filename):
    """
    Melayani gambar profil dari direktori yang telah dikonfigurasi.
    """
    upload_folder = app.config['UPLOAD_FOLDER']
    file_path = os.path.join(upload_folder, filename)

    # Periksa apakah file ada di direktori yang diizinkan
    if not os.path.exists(file_path):
        abort(404, description="File tidak ditemukan")

    return send_from_directory(upload_folder, filename)

# Fungsi logout
def logout():
    session.pop('user_id', None)
    session.pop('username', None)
    # flash('Anda telah logout.', 'info')
    return redirect(url_for('index'))

from AplikasiKu.app import mysql
import traceback
from werkzeug.security import check_password_hash,generate_password_hash


def update_user_profile_picture(user_id, profile_picture):
    """
    Memperbarui foto profil pengguna yang sudah ada di tabel users.
    """
    try:
        # Pastikan parameter profile_picture tidak kosong
        if not profile_picture:
            raise ValueError("profile_picture tidak boleh kosong.")

        # Membuka cursor untuk query database
        cursor = mysql.connection.cursor()

        # Cek apakah user_id valid
        cursor.execute("SELECT 1 FROM users WHERE id = %s", (user_id,))
        if cursor.fetchone() is None:
            raise ValueError(f"User dengan ID {user_id} tidak ditemukan.")

        # Jalankan query update
        cursor.execute("""
            UPDATE users
            SET profile_picture = %s
            WHERE id = %s
        """, (profile_picture, user_id))

        # Commit perubahan ke database
        mysql.connection.commit()

    except Exception as e:
        # Menampilkan pesan error yang lebih jelas
        print("Error:", e)
        print(traceback.format_exc())  # Mencetak traceback
        mysql.connection.rollback()  # Rollback jika terjadi kesalahan
        raise

    finally:
        # Pastikan cursor ditutup
        cursor.close()

def get_user_by_email(email):
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
        cursor.close()
        return user

def email_exists(email):
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
        result = cursor.fetchone()
        cursor.close()
        return result is not None

def verify_password(hashed_password, password):
        return check_password_hash(hashed_password, password)

def create_user(username, email, password):
        hashed_password = generate_password_hash(password)
        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO users (username, email, password) VALUES (%s, %s, %s)",
                   (username, email, hashed_password))
        mysql.connection.commit()
        cursor.close()

def get_user_pekerjaan(user_id):
        cursor = mysql.connection.cursor()
        cursor.execute("""
                SELECT *
        FROM pekerjaan p
        JOIN daftar_pelamar d ON d.pekerjaan_id = p.id
        WHERE d.user_id = %s
        """, (user_id,))
        pekerjaan = cursor.fetchall()
        cursor.close()
        return pekerjaan

def get_all_jobs():
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM pekerjaan")
        jobs = cursor.fetchall()
        cursor.close()
        return jobs

def get_jobs_by_experience(experience):
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM pekerjaan WHERE posisi LIKE %s", (experience,))
        jobs = cursor.fetchall()
        return jobs


def explore(sort_by):
        cursor=mysql.connection.cursor()
        if sort_by == 'asc':
           query = "SELECT * FROM pekerjaan ORDER BY gaji ASC"
        elif sort_by == 'dsc':
           query= "SELECT * FROM pekerjaan ORDER BY gaji DESC"
        else:
           query= "SELECT * FROM pekerjaan ORDER BY created_at DESC"
        cursor.execute(query)
        pekerjaan=cursor.fetchall()
        return pekerjaan

def get_jobs(experience):
        cursor = mysql.connection.cursor()
        query = "SELECT * FROM pekerjaan WHERE posisi LIKE %s"
        cursor.execute(query, (f"%{experience}%",))
        jobs = cursor.fetchall()
        return jobs

def get_job_by_categories(kategori_id):
        cursor=mysql.connection.cursor()
        cursor.execute("SELECT * FROM pekerjaan WHERE kategori_id=%s",(kategori_id,))
        kategori_j=cursor.fetchall()
        return kategori_j

def get_job_sebagian():
        cursor=mysql.connection.cursor()
        cursor.execute("SELECT * FROM pekerjaan ORDER BY created_at DESC LIMIT 3")
        pekerjaan_s=cursor.fetchall()
        return pekerjaan_s
        

def get_jobs_by_id(pekerjaan_id):
        cursor=mysql.connection.cursor()
        cursor.execute("SELECT * FROM pekerjaan where id=%s", (pekerjaan_id,))
        return cursor.fetchone()

def get_jobs_by_id_2(id):
        cursor=mysql.connection.cursor()
        cursor.execute("SELECT * FROM pekerjaan where id=%s", (id,))
        return cursor.fetchone()

def delete_job_by_id(pekerjaan_id):
        cursor=mysql.connection.cursor()
        cursor.execute("DELETE FROM daftar_pelamar WHERE pekerjaan_id = %s", (pekerjaan_id,))
        mysql.connection.commit() 
       
 
def jobs_category():
        cursor=mysql.connection.cursor()
        cursor.execute("SELECT * FROM kategori")
        kategori=cursor.fetchall()
        return kategori

def add_jobs(posisi,perusahaan,lokasi,gaji, deskripsi, requirement,kategori_id): 
        cursor=mysql.connection.cursor()
        cursor.execute("INSERT INTO pekerjaan (posisi,Perusahaan,lokasi,gaji,description,requirement,kategori_id) VALUES (%s,%s,%s,%s,%s,%s,%s)",(posisi,perusahaan,lokasi,gaji, deskripsi, requirement,kategori_id))
        mysql.connection.commit()
        cursor.close()

def add_pelamar(nama, email, no_tlp, pendidikan, skill, pekerjaan_id, user_id, cv_path):
    cursor = mysql.connection.cursor()
    cursor.execute("""
        INSERT INTO daftar_pelamar (nama, email, no_tlp, pendidikan, skill, pekerjaan_id, user_id, cv_path)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """, (nama, email, no_tlp, pendidikan, skill, pekerjaan_id, user_id, cv_path))
    mysql.connection.commit()
    cursor.close()


def daftar_pelamar_by_job(pekerjaan_id):
        cursor=mysql.connection.cursor()
        cursor.execute("SELECT nama,email,pendidikan FROM daftar_pelamar WHERE pekerjaan_id=%s",(pekerjaan_id,))
        return cursor.fetchall()

def delete_user_profile_picture(user_id):
    cursor = mysql.connection.cursor()
    cursor.execute("UPDATE users SET profile_picture = NULL WHERE id = %s", (user_id,))
    mysql.connection.commit()
    cursor.close()

def get_user_profile_picture(user_id):
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT profile_picture FROM users WHERE id = %s", (user_id,))
    result = cursor.fetchone()
    cursor.close()
    return result[0] if result else None

def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
        
def allowed_file1(filename):
    ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'gif'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
